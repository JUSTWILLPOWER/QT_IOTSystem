--use sjson
_G.cjson = sjson
--modify DEVICEID1  APIKEY1

DEVICEID1 = "xxxxx"--设备的id
APIKEY1 = "xxxx"--设备的apikey1

host = host or "www.bigiot.net"
port = port or 8181
LED1 = 1
SWITCH1 = 2

pin = 4  --DHT11数据端口
isConnect1 = false
--初始化
gpio.mode(LED1,gpio.INPUT) 
gpio.mode(SWITCH1,gpio.INPUT) 

gpio.write(LED1,gpio.LOW)
gpio.write(SWITCH1,gpio.LOW)
--建立连接
cu1 = net.createConnection(net.TCP)
isConnect1 = true
local function run1() 
  --接收到消息时间响应
  cu1:on("receive", function(cu1, c) 
    print(c)
    isConnect1 = true
    r = cjson.decode(c)
    if r.M == "say" then
      if r.C == "ledon" then   
        gpio.write(LED1, gpio.HIGH)  
        ok, played = pcall(cjson.encode, {M="say",ID=r.ID,C="LED1 turn on!"})
        cu1:send( played.."\n" )
      end
      if r.C == "switchon" then   
        gpio.write(SWITCH1, gpio.HIGH)  
        ok, played = pcall(cjson.encode, {M="say",ID=r.ID,C="SWITCH1 turn on!"})
        cu1:send( played.."\n" )
      end

      if r.C == "ledoff" then   
        gpio.write(LED1, gpio.LOW)
        ok, stoped = pcall(cjson.encode, {M="say",ID=r.ID,C="LED1 turn off!"})
        cu1:send( stoped.."\n" ) 
      end
      
      if r.C == "switchoff" then   
        gpio.write(SWITCH1, gpio.LOW)
        ok, stoped = pcall(cjson.encode, {M="say",ID=r.ID,C="SWITCH1 turn off!"})
        cu1:send( stoped.."\n" ) 
      end
      
    end
  end)
  --断开连接响应
  cu1:on('disconnection',function(scu)
    cu1 = nil
    isConnect1 = false
    --停止心跳包发送定时器，5秒后重试
    tmr.stop(1)
    tmr.alarm(6, 3000, 0, run1)
  end)
  cu1:connect(port, host)
  ok, s = pcall(cjson.encode, {M="checkin",ID=DEVICEID1,K=APIKEY1})
  if ok then
    print(s)
  else
    print("failed to encode!")
  end
  tmr.delay(10000)
  if isConnect1 then
    cu1:send(s.."\n")
  end
  tmr.alarm(1, 25000, 1, function()
    if isConnect1 then
      cu1:send(s.."\n")
    end
  end)
end
--定时获取温度
tmr.alarm(0, 10000, 1, function()
status, temp, humi, temp_dec, humi_dec = dht.read(pin)
if status == dht.OK then
   if isConnect1 then
    if temp > 10 then
    cu1:send(string.format("{\"M\":\"update\",\"ID\":\"主设备ID\",\"V\":{\"所属设备1ID\":\"%d\",\"所属设备2ID\":\"%d\"}}\n",
            ( math.floor(temp)*0.0406 - 3 ), --减去补偿
            ( math.floor(humi)*0.041 )  
      ))
    end
   end
 --   print(string.format("DHT Temperature:%d;Humidity:%d\r\n",
 --         ( math.floor(temp)*0.0406 ),
 --         ( math.floor(humi)*0.041 )  
 --   ))
elseif status == dht.ERROR_CHECKSUM then
    print( "DHT Checksum error." )
elseif status == dht.ERROR_TIMEOUT then
    print( "DHT timed out." )
end
end)

run1()



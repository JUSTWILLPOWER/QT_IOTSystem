#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "controlwindow.h"

using namespace std;
MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    //修改图标
    setWindowIcon(QIcon(":/img/gnome-run.png"));
}
MainWindow::~MainWindow()
{
    delete ui;
}

int loggedin=0; //登录标志位
QString temp, user, pass;
//检查用户名是否重复
int checkRegister(QString username)
{
    if (username != "") {
        QFile dat(Password_Path);
        dat.open(QIODevice::ReadOnly | QFile::Text);
        QTextStream in(&dat);
        while (!in.atEnd()) {
            temp = in.readLine();
            user = temp.section("#",0,0);
            if (username == user) {
                return 1;
            }
        }
    }
    return 0;
}
//检查登录是否有效
int checkLogin(QString username, QString password)
{
    if (username != "" && password != "") {
        QFile dat(Password_Path);
        dat.open(QIODevice::ReadOnly | QFile::Text);
        QTextStream in(&dat);
        while (!in.atEnd()) {
            temp = in.readLine();
            user = temp.section("#",0,0);
            pass = temp.section("#",1,1);
            if (username == user) {
                //取消了加密
                //if (QString(QCryptographicHash::hash((password.toUtf8()),QCryptographicHash::Md5).toHex()) == pass) {
                if (password == pass) {
                    return 1;
                }
            }
        }
    }
    return 0;
}
//是否显示密码
void MainWindow::on_checkBox_stateChanged(int arg1)
{
    if (arg1 == Qt::Checked) // "选中"
    {
        ui->passwordlineEdit->setEchoMode(QLineEdit::Normal);
    }
    else // 未选中 - Qt::Unchecked
    {
        ui->passwordlineEdit->setEchoMode(QLineEdit::Password);
    }
}
//登录按键按下事件
void MainWindow::on_loginButton_clicked()
{
    QMessageBox msgBox; //信息类
    if(loggedin==0) //如果未登录
    {
        //将用户输入的用户名和密码进行核对
        loggedin = checkLogin(ui->countlineEdit->text(),ui->passwordlineEdit->text());
        if(loggedin==1)
        {
            msgBox.information(this, "登录信息", "登录成功");
			//登录成功则转换窗口
            ControlWindow *sf1 = new ControlWindow();
			//检查用户的权限
            sf1->AuthLevel = (ui->countlineEdit->text() == "1152679377")? 1:0;
			//初始化温度
            readConfig(&sf1->TempMax, &sf1->TempMin);
            sf1->setWindow();
            this->hide();
            sf1->show();
        }
        else
        {
            msgBox.warning(this, tr("Warning!"), tr("用户名或密码错误!"));
        }
    }
    else
    {
        loggedin=0;
    }
}
//注册按钮按下事件
void MainWindow::on_SignButton_clicked()
{
    QMessageBox msgBox;
    if(checkRegister(ui->countlineEdit->text())!=1){
		//对用户名为空，用户名与密码相同，密码低于四位的不予通过
        if(ui->countlineEdit->text()!="" && ui->countlineEdit->text() != ui->passwordlineEdit->text() &&  ui->passwordlineEdit->text().size()>4)
        {
            QString strusername, strpassword, encryptionpass, deencryptionpass;
            QFile dat(Password_Path);
            strusername=ui->countlineEdit->text();
            strpassword=ui->passwordlineEdit->text();
                try {
                    dat.open(QIODevice::Append | QFile::Text);
                    QTextStream out(&dat);
                    out << strusername + "#";
                    //加密
                    //out << QString(QCryptographicHash::hash((strpassword.toUtf8()),QCryptographicHash::Md5).toHex()) + "\n";
                    out << strpassword + '\n';
                }
                catch(const exception& e) {
                    QMessageBox::critical(0,"Error",e.what());
                };
            dat.flush();
            dat.close();
            msgBox.information(this, "注册信息", "注册成功");
        }
        else if(ui->countlineEdit->text()=="")
            QMessageBox::information(this,"Error","用户名不能为空!");
        else if(ui->countlineEdit->text() == ui->passwordlineEdit->text())
            QMessageBox::information(this,"Error","用户名和密码不能相同!");
        else if(ui->passwordlineEdit->text().size()<4)
            QMessageBox::information(this,"Error","密码不能低于4位!");
    }
    else
        QMessageBox::information(this,"Error","用户名已经被注册!");
}
//在输入用户名按下回车后
void MainWindow::on_countlineEdit_returnPressed()
{
    ui->passwordlineEdit->setFocus();
    if(ui->countlineEdit->text()=="")
    ui->passwordlineEdit->clear();
}
//输入密码按下回车后
void MainWindow::on_passwordlineEdit_returnPressed()
{
    ui->loginButton->clicked();
}
//忘记密码按钮按下事件
void MainWindow::on_forgetButton_clicked()
{
    Forgetwindow *forgetwindow = new Forgetwindow();
    forgetwindow->setWindowTitle("忘记密码");
    forgetwindow->setWindowIcon(QIcon(":/img/gnome-run.png"));
	//模态窗口
    forgetwindow->setAttribute(Qt::WA_ShowModal, true);
    forgetwindow->show();
}
//读取设定的温度上下限
void MainWindow::readConfig(uint *Max, uint *Min)
{
    QString temp, tMax, tMin;
    try {
        QFile dat(Config_Path);
        dat.open(QIODevice::ReadOnly | QFile::Text);
        QTextStream in(&dat);
        temp = in.readLine();
        tMax = temp.section("℃",0,0);
        tMin = temp.section("℃",1,1);
        *Max = tMax.toUInt();
        *Min = tMin.toUInt();
    }
    catch(const exception& e) {
        QMessageBox::critical(0,"Error",e.what());
    };
}



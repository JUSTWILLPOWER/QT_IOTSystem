#include "controlwindow.h"
#include "Timewindow.h"
#include "ui_controlwindow.h"
ControlWindow::ControlWindow(QWidget *parent) :
	QMainWindow(parent),
	ui(new Ui::ControlWindow)
{
	ui->setupUi(this);
	setWindowIcon(QIcon(":/img/gnome-run.png"));
	//初始化窗口
	initInfo();
}
ControlWindow::~ControlWindow()
{
	delete ui;
}
//接受到来自服务器的数据
void ControlWindow::socket_Read_Date()
{
	QByteArray buffer;
	buffer = socket->readAll();
	QJsonObject json;
	//通过json文档将json字符串转换为对象
	json = QJsonDocument::fromJson(buffer).object();
	if(!buffer.isEmpty())
	{
		//通过状态来处理相应的接受数据
		switch (socketState)
		{
			case STATE_SININ:
				//登录数据
				qDebug()<<tr(buffer);
				break;
				//登录的时候获取当前硬件状态
			case STATE_GET:
				{
					//根据状态来显示当前UI的界面
					(json.value("C") == "1")? ui->label_light->setStyleSheet("image: url(:/img/beepon.png)") : ui->label_light->setStyleSheet("image: url(:/img/beepoff.png)");
					(json.value("SIGN") == "1")?ui->label_switch->setStyleSheet("image: url(:/img/buttonon.png)"):ui->label_switch->setStyleSheet("image: url(:/img/buttonoff.png)");
					qDebug()<<tr(buffer);
					//改变当前接受状态
					socketState = STATE_NORMAL;
				}
				break;
			case STATE_SEDN:
				qDebug()<<tr(buffer);
				//如果是发送数据状态，则不对接受的数据做处理，只将其输出调试
				socketState = STATE_NORMAL;
				break;
				//普通状态，对接受到的温度数据做处理
			case STATE_NORMAL:
				{
					//将温度的数据从json对象中进行提取
					QString Data = json.value("V").toObject().value("14786").toString();
					//转换为int类型
					int Intdata = Data.toUInt();
					if(Intdata != 0)
					{
						ui->label_data->setText(Data);
					}
					qDebug()<<Intdata;
					//根据温度上下限，对数据做出处理，当出现超过温度上下限，对ui做出调整
					if(ui->spinBox_Max->value() < Intdata)
					{
						qDebug()<<"max";
						ui->label_hmax->setStyleSheet("color: rgb(255, 0, 0);");
					}
					else if(ui->spinBox_Min->value() > Intdata)
					{
						qDebug()<<"min";
						ui->label_hmin->setStyleSheet("color: rgb(255, 0, 0);");
					}
					else
					{
						ui->label_hmax->setStyleSheet("color: rgb(0, 0, 0);");
						ui->label_hmin->setStyleSheet("color: rgb(0, 0, 0);");
					}
				}
				break;
		}
	}
}
//登录服务器
void ControlWindow::socketLink(void)
{
	QJsonObject jsondata;
	socket->abort();
	socket->connectToHostEncrypted("www.bigiot.net",8585);
	if(!socket->waitForConnected(30000))
	{
		qDebug()<<"error";
	}
	else
	{
		socketState = STATE_SININ;
		jsondata.insert("M","login");
        jsondata.insert("ID",ID);
        jsondata.insert("K",IDKEY);
		socket->write((QJsonDocument(jsondata).toJson(QJsonDocument::Compact)).append('\n'));
	}
}
//开灯命令
void ControlWindow::on_pushButton_lighton_clicked()
{
	socketState = STATE_SEDN;
	QJsonObject jsondata;
	jsondata.insert("M","say");
    jsondata.insert("ID",DEVICEID);
    jsondata.insert("C","ledon");
	socket->write((QJsonDocument(jsondata).toJson(QJsonDocument::Compact)).append('\n'));
	ui->label_light->setStyleSheet("image: url(:/img/beepon.png)");
	//记录命令
	writeCmd(Cmd_Path, "Light on");
}
//关灯命令
void ControlWindow::on_pushButton_lightoff_clicked()
{
	socketState = STATE_SEDN;
	QJsonObject jsondata;
	jsondata.insert("M","say");
    jsondata.insert("ID",DEVICEID);
	jsondata.insert("C","ledoff");
	socket->write((QJsonDocument(jsondata).toJson(QJsonDocument::Compact)).append('\n'));
	ui->label_light->setStyleSheet("image: url(:/img/beepoff.png)");
	writeCmd(Cmd_Path, "Light off");
}
//打开继电器
void ControlWindow::on_pushButton_switchon_clicked()
{
	socketState = STATE_SEDN;
	QJsonObject jsondata;
	jsondata.insert("M","say");
    jsondata.insert("ID","DEVICEID");
	jsondata.insert("C","switchon");
	socket->write((QJsonDocument(jsondata).toJson(QJsonDocument::Compact)).append('\n'));
	ui->label_switch->setStyleSheet("image: url(:/img/buttonon.png)");
	writeCmd(Cmd_Path, "Switch on");
}
//关闭继电器
void ControlWindow::on_pushButton_switchoff_clicked()
{
	QJsonObject jsondata;
	socketState = STATE_SEDN;
	jsondata.insert("M","say");
    jsondata.insert("ID",DEVICEID);
	jsondata.insert("C","switchoff");
	socket->write((QJsonDocument(jsondata).toJson(QJsonDocument::Compact)).append('\n'));
	ui->label_switch->setStyleSheet("image: url(:/img/buttonoff.png)");
	writeCmd(Cmd_Path, "Switch off");
}
//发送心跳
void ControlWindow::pollStart()
{
	socket->write("{\"M\":\"beat\"}\n");

}
//开机即获取当前硬件状态
void ControlWindow::getState()
{
	QJsonObject jsondata;
	socketState = STATE_GET;
	jsondata.insert("M","say");
    jsondata.insert("ID",DEVICEID);
	jsondata.insert("C","stateget");
	socket->write((QJsonDocument(jsondata).toJson(QJsonDocument::Compact)).append('\n'));
	//停止获取
	GetStateTimer->stop();
}
void ControlWindow::setWindow()
{
	//窗口的控制显示设置
	ui->spinBox_Max->setValue(this->TempMax);
	ui->spinBox_Min->setValue(this->TempMin);
	QGridLayout *layout = new QGridLayout;
	layout->addWidget(ui->listView, 0, 0);
	layout->addWidget(ui->listView_cmd, 0, 1);
	ui->groupBox->setLayout(layout);
	QHBoxLayout *mainLayout = new QHBoxLayout;
	mainLayout->addWidget(ui->groupBox);
	setLayout(mainLayout);
	//根据用户的权限来决定控件的显示
	if(AuthLevel != 1)
	{
		ui->spinBox_Max->setReadOnly(1);
		ui->spinBox_Min->setReadOnly(1);
		ui->pushButton_lighton->setEnabled(0);
		ui->pushButton_lightoff->setEnabled(0);
		ui->pushButton_switchon->setEnabled(0);
		ui->pushButton_switchoff->setEnabled(0);
		ui->pushButton_add->setEnabled(0);
		ui->pushButton_2->setEnabled(0);
	}
	//获取已经记录的命令
	freshList();
}
//上下限温度写入函数
void ControlWindow::writeConfig(QString Path, QString Max, QString Min)
{
	QFile dat(Path);
	dat.open(QIODevice::ReadWrite | QFile::Text);
	QTextStream out(&dat);
	out << Max ;
	out << Min + '\n';
	dat.flush();
	dat.close();
}
//添加定时器事件
void ControlWindow::on_pushButton_add_clicked()
{
	//定时器添加子窗口
	Timewindow *TimeSet = new Timewindow();
	//添加完成后，将子窗口的数据传到此窗口来的信号与槽函数的连接
	void(Timewindow:: *timeSignal) (QString) = &Timewindow::sendData;
	void(ControlWindow:: *receiveSlot) (QString) = &ControlWindow::receiveData;
	connect(TimeSet, timeSignal, this, receiveSlot);
	TimeSet->setWindowTitle("添加定时器");
	TimeSet->setWindowIcon(QIcon(":/img/gnome-run.png"));
	TimeSet->show();
}
void ControlWindow::getFous(QModelIndex index)
{
	//获取当前选中的行的位置
	SelectIndex = index.row();
}
void ControlWindow::getFous_Cmd(QModelIndex index)
{
	SelectIndex_Cmd = index.row();
}
//删除定时器按钮事件
void ControlWindow::on_pushButton_2_clicked()
{
	Timeinfo.removeAt(SelectIndex);
	//在删除非第一个定时器的时候，需要将删除处的定时器以后的定时器提前
	if(SelectIndex != TimelistNumber)
	{
		for(int i = SelectIndex; i < 19; i++)
		{
			Timelist[i] = Timelist[i + 1];
		}
		TimelistNumber--;
	}
	else
	{
		TimelistNumber--;
	}
	QStringListModel *model = new QStringListModel(Timeinfo);
	//重新刷新列表
	ui->listView->setModel(model);
}
//删除命令的事件相应
void ControlWindow::on_pushButton_delet_clicked()
{
	Cmdinfo.removeAt(SelectIndex_Cmd);
	QFile dat(Cmd_Path);
	dat.open(QIODevice::WriteOnly | QFile::Text);
	QTextStream in(&dat);
	//将cmdinfo字符串列表的数据转换为字符串(以\n为分割符号)导入到文件中
	in << Cmdinfo.join("\n");
	//    dat.write(Cmdinfo.join("\n").toLatin1());
	QStringListModel *model = new QStringListModel(Cmdinfo);
	ui->listView_cmd->setModel(model);
}
//接收到来自添加定时器确定按钮的信号后的相应函数
void ControlWindow::receiveData(QString data)
{
	if(TimelistNumber < 20)
	{
		QString timeData;
		//将小时、分钟、秒钟的数据提取出来，并且装换为uint
		QString Hour, Minute, Second;
		uint uHour, uMinute, uSecond;
		Hour = data.section("#",0, 0);
		Minute = data.section("#",1, 1);
		Second = data.section("#",2, 2);
		uHour = Hour.toUInt();
		uMinute = Minute.toUInt();
		uSecond = Second.toUInt();
		//对不满足二位数的，补齐
		(uHour < 10 )? timeData.append( "0" + Hour + ":"):timeData.append(Hour + ":");
		(uMinute < 10 )? timeData.append( "0" + Minute + ":"):timeData.append(Minute + ":");
		(uSecond < 10 )?timeData.append("0" + Second):timeData.append(Second);
		(data.section("#",3, 3) == '1')?timeData.append("开"):timeData.append("关");
		//加入定时器数据
		Timeinfo.append(timeData);
		QStringListModel *model = new QStringListModel(Timeinfo);
		//加入定时器列表
		Timelist[TimelistNumber].state = data.section("#", 3, 3).toInt();
		Timelist[TimelistNumber].aHour = uHour;
		Timelist[TimelistNumber].aMinute = uMinute;
		Timelist[TimelistNumber++].aSecond = uSecond;
		//刷新定时器列表
		ui->listView->setModel(model);
		//记录加入定时器的命令
		writeCmd(Cmd_Path, timeData);
	}
	else
	{
		QMessageBox::information(this, "Error", "超过定时器上限");
	}
}
void ControlWindow::show_time()
{
	QTime time=QTime::currentTime();//获取系统时间
	//设置时间格式
	QString time_text=time.toString("hh : mm : ss");
	ui->label->setText(time_text);
	//对定时器列表进行轮询，对到事件的定时器做出处理
	if(Timelist[0].aHour != 0)
	{
		for(uint i = 0; i < TimelistNumber; i++)
		{
			if(Timelist[i].aHour == time.hour() && Timelist[i].aMinute == time.minute() && Timelist[i].aSecond == time.second())
			{
				(Timelist[i].state == 1)? on_pushButton_lighton_clicked():on_pushButton_lightoff_clicked();
				SelectIndex = i;
				on_pushButton_2_clicked();
				//删除已经处理的定时器
			}
		}
	}
}
//温度上限进行更变的时候
void ControlWindow::on_spinBox_Max_valueChanged(int arg1)
{
	this->TempMax = arg1;
	ui->spinBox_Min->setMaximum(arg1);
	//将值写入配置文件中
	writeConfig(Config_Path, ui->spinBox_Max->text() ,ui->spinBox_Min->text());
}
//温度下限进行更变的时候
void ControlWindow::on_spinBox_Min_valueChanged(int arg1)
{
	this->TempMin = arg1;
	ui->spinBox_Max->setMinimum(arg1);
	//将值写入配置文件中
	writeConfig(Config_Path, ui->spinBox_Max->text() ,ui->spinBox_Min->text());
}
//初始化
void ControlWindow::initInfo()
{
	//设置温度上下限空间显示后缀
	ui->spinBox_Max->setSuffix("℃");
	ui->spinBox_Min->setSuffix("℃");
	ControlWindow::socketLink();
	//显示时间的类创建，以及连接槽函数
	QTimer *timer=new QTimer(this);
	//系统时间显示槽函数与信号连接
	connect(timer, SIGNAL(timeout()), this, SLOT(show_time()));
	timer->start(300);
	pollTimer->start(10000);
	GetStateTimer->start(1500);
	QStringListModel *model = new QStringListModel(Timeinfo);
	ui->listView->setModel(model);
	connect(ui->listView, SIGNAL(clicked(QModelIndex)), this, SLOT(getFous(QModelIndex)));
	connect(ui->listView_cmd, SIGNAL(clicked(QModelIndex)), this, SLOT(getFous_Cmd(QModelIndex)));
	connect(socket, &QSslSocket::readyRead, this, &ControlWindow::socket_Read_Date);
	connect(pollTimer, &QTimer::timeout,this, &ControlWindow::pollStart);
	connect(GetStateTimer, &QTimer::timeout,this, &ControlWindow::getState);
}
//写入命令函数，将执行命令的时间放在前面
void ControlWindow::writeCmd(QString Path, QString Cmd)
{
	QTime time=QTime::currentTime();//获取系统时间
	//设置时间格式
	QString time_text=time.toString("hh : mm : ss");
	QFile dat(Path);
	dat.open(QIODevice::Append | QFile::Text);
	QTextStream out(&dat);
	out << time_text.remove(QRegExp("\\s")) + "   ";
	out << Cmd + '\n';
	dat.close();
	freshList();
}
//刷新列表函数
void ControlWindow::freshList(void)
{
	//将文件中的值读出来然后刷新当前显示
	QFile dat(Cmd_Path);
	Cmdinfo.clear();
	dat.open(QIODevice::ReadWrite | QFile::Text);
	QTextStream in(&dat);
	while (!in.atEnd())
		Cmdinfo << in.readLine();
	QStringListModel *model = new QStringListModel(Cmdinfo);
	ui->listView_cmd->setModel(model);
}


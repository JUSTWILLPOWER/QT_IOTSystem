#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <controlwindow.h>
#include <QFile>
#include "ui_mainwindow.h"
#include "QString"
#include "QMessageBox"
#include "QTextStream"
#include "QFile"
#include "QDebug"
#include "algorithm"
#include "QCryptographicHash"
#include "QByteArray"
#include "forgetwindow.h"

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private:
    void readConfig(uint *Max, uint *Min);

private slots:
//    void on_lineEdit_selectionChanged();
    void on_checkBox_stateChanged(int arg1);
    void on_loginButton_clicked();
    void on_SignButton_clicked();
    void on_countlineEdit_returnPressed();
    void on_passwordlineEdit_returnPressed();
    void on_forgetButton_clicked();

private:
    Ui::MainWindow *ui;
};
#endif // MAINWINDOW_H

#ifndef TIMEWINDOW_H
#define TIMEWINDOW_H
#include <QMainWindow>
#include <QtDebug>
#include <QMessageBox>
#include <QGroupBox>
#include <QComboBox>
#include <QGridLayout>
#include <QWidget>
#include <QLabel>
#include <QFile>
#include "QCryptographicHash"
#include <QPushButton>
#include <QRegExp>
#include <QRegExpValidator>
#include <QRadioButton>
#include <QComboBox>

class Timewindow : public QWidget
{
    Q_OBJECT
public:
    explicit Timewindow(QWidget *parent = nullptr);
private slots:
    void AddTimer();
    void SwitchChanged(bool state);
private:
    void creatForgetGroupBox();
    QGroupBox *forgetGroupBox;
    QComboBox *ComboBox_Hour;
    QLabel *Label_Hour;
    QComboBox *ComboBox_Minute;
    QLabel *Label_Minute;
    QComboBox *ComboBox_Second;
    QLabel *Label_Second;
    QPushButton *FishedButton;
    QRadioButton *switchButton;
    void ComboBoxInit();
signals:
    void sendData(QString);
};



#endif // TIMEWINDOW_H

#include "Timewindow.h"
Timewindow::Timewindow(QWidget *parent) :
    QWidget(parent)
{
    creatForgetGroupBox();
    QHBoxLayout *mainLayout = new QHBoxLayout;
    mainLayout->addWidget(forgetGroupBox);
	//设置窗口组件
    setLayout(mainLayout);
	//设置窗口为模态
    setAttribute(Qt::WA_ShowModal, true);
    void(QRadioButton:: *switchChangedSignal)(bool) = &QRadioButton::toggled;
    //谁的信号就用谁的类
    void(Timewindow::*switchChangedSlot)(bool) = &Timewindow::SwitchChanged;
    ComboBoxInit();
    //注意先初始化，再连接信号与槽函数
    connect(this->FishedButton, &QPushButton::clicked, this,&Timewindow::AddTimer);
    connect(this->switchButton, switchChangedSignal, this, switchChangedSlot);
}
//设置添加定时器子窗口显示控件
void Timewindow::creatForgetGroupBox(void)
{
    forgetGroupBox = new QGroupBox(tr("设置定时器"));
    ComboBox_Hour = new QComboBox();
    ComboBox_Minute = new QComboBox();
    ComboBox_Second = new QComboBox();
    Label_Hour = new QLabel("小时");
    Label_Minute = new QLabel("分钟");
    Label_Second = new QLabel("秒钟");
    FishedButton = new QPushButton("确认");
    switchButton = new QRadioButton("关");
    QGridLayout *layout = new QGridLayout;
    layout->addWidget(ComboBox_Hour, 0, 0);
    layout->addWidget(Label_Hour, 0, 1);
    layout->addWidget(ComboBox_Minute, 1, 0);
    layout->addWidget(Label_Minute, 1, 1);
    layout->addWidget(ComboBox_Second, 2, 0);
    layout->addWidget(Label_Second, 2, 1);
    layout->addWidget(switchButton, 3, 1);
    layout->addWidget(FishedButton, 4, 1);
    forgetGroupBox->setLayout(layout);
}
//添加定时器
void Timewindow::AddTimer()
{
    QString data;
    QString dataHour, dataMinute, dataSecond;
	//获取组件数据
    dataHour = ComboBox_Hour->itemText(ComboBox_Hour->currentIndex());
    dataMinute = ComboBox_Minute->itemText(ComboBox_Minute->currentIndex());
    dataSecond = ComboBox_Second->itemText(ComboBox_Second->currentIndex());
    data.append(dataHour);
    data.append("#" + dataMinute);
    data.append("#" + dataSecond);
    data.append("#" + QString::number(switchButton->isChecked()));
    qDebug()<<data;
	//发送完成添加定时器信号,并将数据发送出去
    emit sendData(data);
    delete this;
}
//选择是开还是关
void Timewindow::SwitchChanged(bool state)
{
    qDebug()<<state;
    if(state == true)
    {
        switchButton->setText("开");
    }
    else
    {
        switchButton->setText("关");
    }
}
void Timewindow::ComboBoxInit()
{
	//comboBox组件初始化
    for(int i = 0; i < 24; i++)
    {
        ComboBox_Hour->addItem(QString::number(i));
    }
    for(int i = 0; i < 60; i++)
    {
        ComboBox_Minute->addItem(QString::number(i));
        ComboBox_Second->addItem(QString::number(i));
    }
    ComboBox_Hour->setMaxVisibleItems(10);
    ComboBox_Minute->setMaxVisibleItems(10);
    ComboBox_Second->setMaxVisibleItems(10);
	//为了在Linux中也能只显示10个预选值
    ComboBox_Hour->setStyleSheet("combobox-popup: 0;");
    ComboBox_Minute->setStyleSheet("combobox-popup: 0;");
    ComboBox_Second->setStyleSheet("combobox-popup: 0;");
}


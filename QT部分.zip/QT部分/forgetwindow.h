#ifndef FORGETWINDOW_H
#define FORGETWINDOW_H
#include <QMainWindow>
#include <QtDebug>
#include <QMessageBox>
#include <QGroupBox>
#include <QLineEdit>
#include <QGridLayout>
#include <QWidget>
#include <QLabel>
#include <QFile>
#include "QCryptographicHash"
#include <QPushButton>

#ifdef Q_OS_LINUX
#define Password_Path "/home/willpower/default/password.txt"
#else
#define Password_Path "c:/Users/WILLPOWER/Desktop/password.txt"
#endif
class Forgetwindow : public QWidget
{
    Q_OBJECT
public:
    explicit Forgetwindow(QWidget *parent = nullptr);
private slots:
    bool editFished();
    void shureButtonClicked();
private:
    void creatForgetGroupBox();
    QGroupBox *forgetGroupBox;
    QLineEdit *usernameLineEdit;
    QLabel *usernameLabel;
    QPushButton *shureButton;
};















#endif // FORGETWINDOW_H

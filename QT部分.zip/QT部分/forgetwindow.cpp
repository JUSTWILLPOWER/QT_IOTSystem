#include "forgetwindow.h"

Forgetwindow::Forgetwindow(QWidget *parent) :
    QWidget(parent)
{
    creatForgetGroupBox();
    QHBoxLayout *mainLayout = new QHBoxLayout;
    mainLayout->addWidget(forgetGroupBox);
    setLayout(mainLayout);
    connect(this->usernameLineEdit, &QLineEdit::editingFinished,this,&Forgetwindow::editFished);
    connect(this->shureButton, &QPushButton::clicked,this,&Forgetwindow::shureButtonClicked);
}

//创建子窗口
void Forgetwindow::creatForgetGroupBox(void)
{
	//设置窗口显示的组件
    forgetGroupBox = new QGroupBox(tr("找回密码"));
    usernameLineEdit = new QLineEdit();
    shureButton = new QPushButton("确定");
    usernameLabel = new QLabel("请输入用户名");
    QGridLayout *layout = new QGridLayout;
    layout->addWidget(usernameLineEdit, 0, 1);
    layout->addWidget(usernameLabel, 0, 0);
    layout->addWidget(shureButton, 1, 1);
    forgetGroupBox->setLayout(layout);
}


//忘记密码按下确定键回调事件
bool Forgetwindow::editFished()
{
//    QMessageBox getpasswdBox;
    QString temp, user, pass;
    if (this->usernameLineEdit->text() != "")
    {
        QFile dat(Password_Path);
        dat.open(QIODevice::ReadOnly | QFile::Text);
        QTextStream in(&dat);
		//对密码进行查询
        while (!in.atEnd())
        {
            temp = in.readLine();
            user = temp.section("#",0,0);
            pass = temp.section("#",1,1);
			//如果找到密码，将密码进行显示
            if (usernameLineEdit->text() == user)
            {
                QMessageBox::information(this, "密码", "密码为:"+pass);
                dat.flush();
                dat.close();
                return 1;
            }
        }
    }
    return 0;
}

void Forgetwindow::shureButtonClicked()
{
    QString temp, user, pass;
    if (this->usernameLineEdit->text() != "")
    {
        QFile dat(Password_Path);
        dat.open(QIODevice::ReadOnly | QFile::Text);
        QTextStream in(&dat);
        //对密码进行查询
        while (!in.atEnd())
        {
            temp = in.readLine();
            user = temp.section("#",0,0);
            pass = temp.section("#",1,1);
            //如果找到密码，将密码进行显示
            if (usernameLineEdit->text() == user)
            {
                QMessageBox::information(this, "密码", "密码为:"+pass);
                dat.flush();
                dat.close();
            }
        }
    }
}













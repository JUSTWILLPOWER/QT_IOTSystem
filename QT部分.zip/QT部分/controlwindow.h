#ifndef CONTROLWINDOW_H
#define CONTROLWINDOW_H

#include <QMainWindow>
#include <QSslSocket>
#include <QtNetwork>
#include <QJsonDocument>
#include <QJsonObject>
#include <QJsonArray>
#include <QTime>
#include <QDebug>
#include <QRegExp>
#include <QRegExpValidator>
#include <QtGlobal>
#include <QMessageBox>
#include <QString>
#include <QFile>
#include <QGridLayout>
#include <QStringList>
#include "QDateTime"
#include "QTimer"
#define STATE_SEDN 1
#define STATE_NORMAL 2
#define STATE_SININ 3
#define STATE_GET 4
#define ID 111
#define IDKEY 222
#define DEVICEID 333



#ifdef Q_OS_LINUX
#define Password_Path "/home/willpower/default/password.txt"
#define Config_Path "/home/willpower/default/config.txt"
#define Cmd_Path "/home/willpower/default/cmd.txt"

#else
#define Password_Path "c:/Users/WILLPOWER/Desktop/password.txt"
#define Config_Path "c:/Users/WILLPOWER/Desktop/config.txt"
#define Cmd_Path "c:/Users/WILLPOWER/Desktop/cmd.txt"
#endif
typedef struct TimeStruct
{
    int aHour;
    int aMinute;
    int aSecond;
    bool state;
}TimeType;
namespace Ui {
class ControlWindow;
}
class ControlWindow : public QMainWindow
{
    Q_OBJECT
public:
    explicit ControlWindow(QWidget *parent = nullptr);
    ~ControlWindow();
    uint TempMax = 24, TempMin = 10;
    uchar AuthLevel;
    void  setWindow();
private slots:
    void on_pushButton_lighton_clicked();
    void on_pushButton_lightoff_clicked();
    void on_pushButton_switchon_clicked();
    void on_pushButton_switchoff_clicked();
    void pollStart(void);
    void getState(void);
    void socket_Read_Date(void);
    void on_pushButton_add_clicked();
    void getFous(QModelIndex index);
    void getFous_Cmd(QModelIndex index);
    void on_pushButton_2_clicked();
    void receiveData(QString data);
    void show_time();
    void on_spinBox_Max_valueChanged(int arg1);
    void on_spinBox_Min_valueChanged(int arg1);
    void initInfo(void);
    void on_pushButton_delet_clicked();

private:
    char socketState = STATE_SININ;
    Ui::ControlWindow *ui;
    QSslSocket *socket = new QSslSocket;
    QTimer *pollTimer = new QTimer(this);
    QTimer *GetStateTimer = new QTimer(this);
    TimeType Timelist[20];
    uint TimelistNumber = 0;
    uchar Rec_socketState = 0;
    uint SelectIndex = 0;
    uint SelectIndex_Cmd = 0;
    QStringList Timeinfo;
    QStringList Cmdinfo;
    void getTemper(void);
    void clearHistory(void);
    void socketLink(void);
    void writeConfig(QString Path, QString Max, QString Min);
    void writeCmd(QString Path, QString Cmd);
    void freshList(void);
};

#endif // CONTROLWINDOW_H
